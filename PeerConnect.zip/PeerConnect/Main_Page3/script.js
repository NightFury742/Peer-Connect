const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        console.log(entry)
        if(entry.isIntersecting){
            entry.target.classList.add('show');
        }
    });
})
const hiddenElements = document.querySelectorAll('.hidden');
hiddenElements.forEach((el) => observer.observe(el));

function dropdown(){
    document.getElementById('nav').style.opacity=1;
    document.getElementById('navbar_icon').style.transform = `translate(-100%)`;
    document.getElementById('x_cross').style.transform = `translate(0)`;
}
function rollin(){
    document.getElementById('nav').style.opacity=0;
    document.getElementById('navbar_icon').style.transform = `translate(0)`;
    document.getElementById('x_cross').style.transform = `translate(-100%)`;
}

const sections = document.querySelectorAll('.section');
const a_tags = document.querySelectorAll('#nav a');

const resetLinks = () => a_tags.forEach(link =>
    link.classList.remove("active"));
const handleScroll = () => {
    const { pageYOffset } = window;
    sections.forEach(section =>{
        const { id, offsetTop, clientHeight } = section;
        const offset = offsetTop - 1 ;
        
        if(pageYOffset >= offset &&
            pageYOffset < offset + clientHeight){
                resetLinks();
                a_tags.forEach(link => {
                    if(link.dataset.scroll === id){
                        link.classList.add("active");
                    }
                });
            }
    });
};
document.addEventListener("scroll",handleScroll);